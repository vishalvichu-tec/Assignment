import calendar  # importing calendar module
yy = 2014  # year
mm = 11    # month
# we can give the year and month we will get the required information
yy = int(input("Enter year: ")) # year is number so int data type is used
mm = int(input("Enter month: ")) # we have to give a month in Number like anything 1-12 we ahve 12 months So we use int data type
print(calendar.month(yy, mm)) # display the calendar