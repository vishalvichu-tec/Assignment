#Student report card
print('Student report card')
print('=======================================')
stud_name=input('Please enter Name :')
stud_age=int(input('Pleae enter Age :'))                           # age is in number so we use int data type
english_marks=int(input('Please enter English marks :'))           # marks is in number so we use int data type
maths_marks=int(input('Please enter Maths marks :'))               # marks is in number so we use int data type
science_marks=int(input('Please enter Science marks :'))           # marks is in number so we use int data type
#Student totals and percentage
stud_total_marks = maths_marks + science_marks + english_marks     # adding the marks respectively
stud_percentage = round(stud_total_marks/300 * 100,2)              #Percentage calculation is performed
#Print student Report card
print('=======================================')
print(f'English       : {english_marks}')
print(f'Maths         : {maths_marks}')
print(f'Science       : {science_marks}')                          # we use this code to dsipaly print English/maths/science/total/perentage
print(f'Total         : {stud_total_marks}')
print(f'Percentage    : {stud_percentage}%')
print('=======================================')
#Student marks classification
if(stud_percentage>=75):
  print('Distinction')                                             #condition used here is student per is >= 75 print distinction
elif stud_percentage >=60 and  stud_percentage< 75:
  print('First Class')                                             # condition used here is studnt per is >=60 Stu per <60 print First class
elif (stud_percentage>35 and stud_percentage<60):
  print('Second class')                                            # condition used here is student per is>35 <60 Print second class
else:
  print('Fail')                                                    #condition used here is if the student is < 35 means he/she is fail
print('=======================================')